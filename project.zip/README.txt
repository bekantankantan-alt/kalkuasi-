SIZE CALCULATOR – KERJAAN SEMUA

Aplikasi Android offline untuk kalkulasi SIZE +50/-50, mode A (input tonase +50) dan mode B (input persentase +50, hasil MT dibulatkan ke puluhan terdekat).

Build APK melalui GitHub Actions:
1. Upload seluruh isi folder proyek ini ke repository GitHub (branch main).
2. Buka tab Actions dan jalankan workflow “Build SIZE CALCULATOR APK” (atau tunggu workflow berjalan setelah push).
3. Buka run yang berhasil, bagian Artifacts, unduh SIZE-CALCULATOR-APK.zip, lalu ekstrak app-debug.apk.
4. Install APK di Android.

Data dan riwayat disimpan secara lokal di WebView perangkat. Aplikasi tidak memerlukan internet untuk kalkulasi.
