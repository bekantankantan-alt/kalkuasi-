plugins {
    id("com.android.application")
}

android {
    namespace = "id.hasim.ubahjamfoto"
    compileSdk = 35

    defaultConfig {
        applicationId = "id.hasim.sizecalculator"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
